import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

public class METODOS extends javax.swing.JFrame{
    CRIP_IMG IMG=new CRIP_IMG();
    JFileChooser abrirArchivo;
    FileNameExtensionFilter filtroImagen;
    FileInputStream fis;
    DataInputStream entrada;;
    int a=256,b;
    public String TXT,DATALEIDA="",DATADC="",TXTDC="";
    double A,K,X0,R1=0.0,G=18.0,M;
    public int Random(){
        if(a==256){
            a=hash(false);
            b=hash(true);
            K=b;
            X0=((a&2)==0)?a+3:a;
            A=5+(8*K);
            M=Math.pow(2, G);
        }
        X0=(X0*A)%M;
        R1=((X0/(M-1))*256);
        return (int)R1;
    }
    public int hash(boolean T){
        double RESUL=0.0;
        if(T){
            for(int x=0;x<CRIPEX16.jTextField5.getText().length();x++){
                RESUL=((Math.pow(CRIPEX16.jTextField5.getText().charAt(x),2)+256+x+RESUL)%(256+x))/(256+x);
            }
        }else{
            for(int x=0;x<CRIPEX16.jTextField3.getText().length();x++){
                RESUL=((Math.pow(CRIPEX16.jTextField3.getText().charAt(x),2)+256+x+RESUL)%(256+x))/(256+x);
            }
        }
        RESUL=RESUL*1000000;
        return (int)(RESUL);
    }
    public void img(ArrayList<Integer>VAL) throws IOException{
        String A1="",A2="",A3="",val;
        int DD=(int)Math.sqrt((VAL.size()/3)+1)+1;
        int N1,N2,N3,LE;
        LE=VAL.size();
        if(LE<=255){
            N1=LE;
            A1=Integer.toHexString(N1);
        }else if(LE>255||LE<65535){
            N2=LE/256;
            A2=Integer.toHexString(N2);
            N1=LE-(N2*256);
            A1=Integer.toHexString(N1);
        }else if(LE>65535){;
            N3=LE/65536;
            A3=Integer.toHexString(N3);
            N2=(LE-(N3*65536))/256;
            A2=Integer.toHexString(N2);
            N1=LE-(N3*65536)-(N2*256);
            A1=Integer.toHexString(N1);
        }
        DD++;
        BufferedImage image = new BufferedImage(DD, DD, BufferedImage.TYPE_INT_RGB);
        val=A3+A2+A1;
        int s=Integer.valueOf(val, 16);
        image.setRGB(0, 0, s);
        int f=0,Ran=0;
        for(int y=0;y<DD;y++)
            for(int x=0;x<DD;x++){
                if(x==0&&y==0)
                    x=1;
                f+=3;
                if(true){
                    if(f<LE+3){
                        if(VAL.get(f-3)<16)
                            A1="0"+Integer.toHexString(VAL.get(f-3));
                        else
                            A1=Integer.toHexString(VAL.get(f-3));
                    }
                    else{
                        Ran=(int)(Math.random()*255);
                        A1=Integer.toHexString(Ran);
                    }
                    if(f<LE+2){
                        if(VAL.get(f-2)<16)
                            A2="0"+Integer.toHexString(VAL.get(f-2));
                        else
                            A2=Integer.toHexString(VAL.get(f-2));
                    }
                    else{
                        Ran=(int)(Math.random()*255);
                        A2=Integer.toHexString(Ran);
                    }
                    if(f<LE+1){
                        if(VAL.get(f-1)<16)
                            A3="0"+Integer.toHexString(VAL.get(f-1));
                        else
                            A3=Integer.toHexString(VAL.get(f-1));
                    }
                    else{
                        Ran=(int)(Math.random()*255);
                        A3=Integer.toHexString(Ran);
                    }
                    val=A1+A2+A3;
                    s=Integer.valueOf(val,16);
                    image.setRGB(x, y, s);
                } 
            }
        File file = new File(CRIPEX16.NAME+".PNG");
        ImageIO.write(image, "png", file);
    }
    public void HASH(String Hash,String Modo) throws IOException{
        MessageDigest m = null;
        try {
            m = MessageDigest.getInstance(Modo);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(CRIPEX16.class.getName()).log(Level.SEVERE, null, ex);
        }
        m.reset();
        m.update(Hash.getBytes());
        byte[] digest = m.digest();
        BigInteger bigInt = new BigInteger(1,digest);
        String hashtext = bigInt.toString(16);
        while(hashtext.length() < 32 ){
            hashtext = "0"+hashtext;
        }
        CRIPEX16.HASH_GENERADO.setText(hashtext.toUpperCase());
        CRIPEX16.HASHM=CRIPEX16.HASH_GENERADO.getText();
        if(CRIPEX16.HASH_GENERADO.getText().equals("C4CA4238A0B923820DCC509A6F75849B")||CRIPEX16.HASH_GENERADO.getText().equals("D41D8CD98F00B204E9800998ECF8427E")){
            CRIPEX16.HASH_GENERADO.setText("");
            CRIPEX16.HASHM="";
        }
    }
    public int DatoHex(int Dato,int DatoRandom,int DatoAterior){
        int temp=Dato+DatoRandom+DatoAterior;
        if(temp>=256){
            temp=temp-256;
            if(temp>=256){
                return temp-256;
            }else{
                return temp;
            }
        }else{
            return temp;
        }
    }
    public int DatoHexDec(int Dato,int DatoRandom,int DatoAnterior){
        int temp=Dato-DatoRandom-DatoAnterior;
        if(temp<=0){
            temp=temp+256;
            if(temp<=0){
                return temp+256;
            }else{
                return temp;
            }
        }else{
            return temp;
        }
    }
    public void ABRIRFILE(){
        abrirArchivo = new JFileChooser();
        String path="";
        abrirArchivo.setFileSelectionMode( JFileChooser.FILES_ONLY );
        int seleccion = abrirArchivo.showOpenDialog( this );
        if( seleccion == JFileChooser.APPROVE_OPTION ){
            File f = abrirArchivo.getSelectedFile();
            try{
                path = f.getAbsolutePath();
            }catch( Exception exp){}
        }
        try {
            fis = new FileInputStream(path);
            entrada = new DataInputStream(fis);
            while( ( TXT = entrada.readLine()) != null ){
                CRIPEX16.jTextArea1.setText(CRIPEX16.jTextArea1.getText().concat(TXT+"\n"));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void ABRIRFILEBIN(){
        abrirArchivo = new JFileChooser();
        abrirArchivo.setDialogTitle("Seleccionar Archivo");
        filtroImagen = new FileNameExtensionFilter("X16KEY","x16key");
        abrirArchivo.setFileFilter(filtroImagen);
        String path="";
        StringBuilder SW_Datos_Leidos;
        abrirArchivo.setFileSelectionMode( JFileChooser.FILES_ONLY );
        long s=0;
        int seleccion = abrirArchivo.showOpenDialog( this );
        int Dat;
        long x=0,T=0L,F=0;
        if( seleccion == JFileChooser.APPROVE_OPTION ){
            File f = abrirArchivo.getSelectedFile();
            try{
                path = f.getAbsolutePath();
                CRIPEX16.name=f.getName();
                CRIPEX16.name=CRIPEX16.name.substring(0, CRIPEX16.name.length()-7);
                s=f.length();
                T=s/1000;
            }catch( Exception exp){}
        }
        try {
            fis = new FileInputStream(path);
            entrada = new DataInputStream(fis);
            CRIPEX16.jTextField1.setText(path);
            SW_Datos_Leidos=new StringBuilder(50000);
            CRIPEX16.jProgressBar1.setMaximum(1000);
            while( ( Dat = entrada.read()) != -1){
                if(CRIPEX16.jCheckBox1.isSelected())
                    CRIPEX16.HASHINT.add(Dat);
                x++;
                if(s>=1000){
                    F=(x%T==0)?F+1:F;
                    CRIPEX16.jProgressBar1.setValue((int)F);
                }
                if(Dat<16){
                    SW_Datos_Leidos=SW_Datos_Leidos.append(("0"+Integer.toHexString(Dat)).toUpperCase());
                    if(x%49999==0){
                        DATALEIDA=DATALEIDA+(SW_Datos_Leidos.toString());
                        SW_Datos_Leidos.delete(0, 49999);
                    }
                }
                else{
                    SW_Datos_Leidos=SW_Datos_Leidos.append((Integer.toHexString(Dat)).toUpperCase());
                    if(x%49999==0){
                        DATALEIDA=DATALEIDA+(SW_Datos_Leidos.toString());
                        SW_Datos_Leidos.delete(0, 49999);
                    }
                }
            }
            if(s%49999>0)
                DATALEIDA=DATALEIDA+(SW_Datos_Leidos.toString());
            entrada.close();
        }catch (Exception e) {
            System.out.println(e.getClass());
        }
    }
    public void RandomKey(){
        CRIPEX16.jTextField4.setText(null);
        boolean CHECK=true;
        String l=null;
        while(CHECK){
            try{
                l=JOptionPane.showInputDialog("Tamaño de la clave");
                for(int x=0;x<Integer.parseInt(l);x++){
                    CRIPEX16.jTextField4.setText(CRIPEX16.jTextField4.getText().concat(Integer.toHexString((int)(Math.random()*256)).toUpperCase()));
                }
                CHECK=false;
            }catch(Exception e){
                if(l!=null){
                    CHECK=true;
                    JOptionPane.showMessageDialog(rootPane, "Solo introducir Numeros", "ERROR", 0);
                }
                else
                    CHECK=false;
            }
        }
    }
    public void DCRIPT(int parametro){
         if(DATALEIDA.length()==0)
            JOptionPane.showMessageDialog(rootPane, "No hay datos", "Error", 0);
        else{
            int DDR=0,G1=0,G2=2;
            int CRY,VAL=0,TEMP=0;
            StringBuilder SB=new StringBuilder(50000);
            for(int x=0;x<(DATALEIDA.length()/2);x++){
                CRY=Integer.parseInt(DATALEIDA.substring(G1, G2),16);
                DDR=Random();
                VAL=DatoHexDec(CRY, DDR, TEMP);
                TEMP=CRY;
                G1+=2;
                G2+=2;
                SB.append(Integer.toHexString(VAL));
                if(x%49999==0){
                    DATADC+=SB.toString();
                    SB.delete(0, 49999);
                }
            }
            if((DATALEIDA.length()/2)%49999>0){
                DATADC+=SB.toString();
            }
        }
        switch(parametro){
            case 0:
                DC_TXT();
                break;
        }
    }
    public void DC_TXT(){
        TXTDC="";
        int G1=0,G2=2,F;
        StringBuilder SB=new StringBuilder(50000);
        for(int x=0;x<(DATADC.length()/2);x++){
            F=(char)Integer.parseInt(DATADC.substring(G1, G2),16);
            SB.append(String.valueOf((char)F));
            if(x%49999==0){
                TXTDC+=SB.toString();
                SB.delete(0, 49999);
            }
            G1+=2;
            G2+=2;
        }
        if((DATADC.length()/2)%49999!=0){
            TXTDC+=SB.toString();
        }
    }
    public void file(int VAL) throws IOException{
        File FW=new File(CRIPEX16.NAME+".x16key");
        try (BufferedOutputStream BW = new BufferedOutputStream(new FileOutputStream(FW,true))) {
            BW.write(VAL);
        }
    }
}
