import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
public class CRIPEX16 extends javax.swing.JFrame implements Runnable {
    CRIP_IMG IMG=new CRIP_IMG();
    METODOS OBJ=new METODOS();
    JFileChooser abrirArchivo;
    FileInputStream fis;
    DataInputStream entrada;;
    Thread h1;
    public static ArrayList<Integer>HASHINT=new ArrayList<>();
    public static String NAME="",contenido="",HASHM,HASHS,name;
    boolean read,abrirf,abriri,FKEY,CRIP,DCRIP;
    public CRIPEX16() {
        initComponents();
    }
    public void run(){
        Thread ct = Thread.currentThread();
        if(CRIP){
            try {
                Crip();
            } catch (IOException ex) {
                Logger.getLogger(CRIPEX16.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else if(read){
            Read();
        }else if(abrirf){
            try {
                AbrirF();
            } catch (IOException ex) {
                Logger.getLogger(CRIPEX16.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else if(DCRIP){
            Dcrip();
        }else if(abriri){
            try {
                Abriri();
            } catch (IOException ex) {
                Logger.getLogger(CRIPEX16.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jTextField1 = new javax.swing.JTextField();
        HASH_GENERADO = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        Random_Key = new javax.swing.JButton();
        jTextField4 = new javax.swing.JTextField();
        Crip = new javax.swing.JButton();
        jTextField5 = new javax.swing.JTextField();
        D_Crip = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel2 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jButton7 = new javax.swing.JButton();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jCheckBox1 = new javax.swing.JCheckBox();
        jRadioButton5 = new javax.swing.JRadioButton();
        jRadioButton6 = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();
        jCheckBox2 = new javax.swing.JCheckBox();
        jProgressBar1 = new javax.swing.JProgressBar();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu2 = new javax.swing.JMenu();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenuItem7 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        jMenu5 = new javax.swing.JMenu();
        jMenuItem8 = new javax.swing.JMenuItem();
        jMenuItem9 = new javax.swing.JMenuItem();
        jMenuItem10 = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem11 = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jTextField1.setEditable(false);
        jTextField1.setToolTipText("Ruta del Archivo o Imagen");

        HASH_GENERADO.setEditable(false);
        HASH_GENERADO.setToolTipText("HASH del archivo o imagen en MD5 o SHA1");

        jLabel1.setText("HASH MD5");

        jTextField3.setToolTipText("Contraceña para la encriptacion");

        Random_Key.setText("R.KEY");
        Random_Key.setToolTipText("Se crea una contraceña con una longitud especifica");
        Random_Key.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Random_KeyActionPerformed(evt);
            }
        });

        jTextField4.setToolTipText("Contraceña aleatoria");

        Crip.setText("CRIP");
        Crip.setToolTipText("Encriptar Texto");
        Crip.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CripActionPerformed(evt);
            }
        });

        jTextField5.setToolTipText("Nombre del archivo o imagen");

        D_Crip.setText("D.CRIP");
        D_Crip.setToolTipText("Desencriptar texto");
        D_Crip.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                D_CripActionPerformed(evt);
            }
        });

        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        jTextArea1.setLineWrap(true);
        jTextArea1.setRows(5);
        jTextArea1.setDoubleBuffered(true);
        jScrollPane1.setViewportView(jTextArea1);

        jLabel2.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel2.setFocusable(false);

        jTextField7.setEditable(false);
        jTextField7.setFocusable(false);

        jTextField8.setEditable(false);
        jTextField8.setFocusable(false);

        jButton7.setText("CLR");
        jButton7.setToolTipText("Limpiar campos");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setSelected(true);
        jRadioButton1.setText("IMG");
        jRadioButton1.setToolTipText("Se creara una imagen a partir del texto");

        buttonGroup1.add(jRadioButton2);
        jRadioButton2.setText("FILE");
        jRadioButton2.setToolTipText("Se creara un archivo a partir del texto");

        jCheckBox1.setSelected(true);
        jCheckBox1.setText("HASH");
        jCheckBox1.setToolTipText("Habilirar o desabilitar la creacion o lectura de HASH");
        jCheckBox1.setEnabled(false);
        jCheckBox1.setFocusable(false);
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        buttonGroup3.add(jRadioButton5);
        jRadioButton5.setSelected(true);
        jRadioButton5.setText("MD5");
        jRadioButton5.setFocusable(false);
        jRadioButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton5ActionPerformed(evt);
            }
        });

        buttonGroup3.add(jRadioButton6);
        jRadioButton6.setText("SHA1");
        jRadioButton6.setFocusable(false);
        jRadioButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton6ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Comic Sans MS", 1, 24)); // NOI18N
        jLabel3.setForeground(java.awt.Color.green);
        jLabel3.setText("LISTO");
        jLabel3.setToolTipText("");

        jCheckBox2.setText("Verificar Integridad");
        jCheckBox2.setToolTipText("Verifica si el archivo fue modificado");
        jCheckBox2.setEnabled(false);

        jLabel4.setText("Nombre del archivo");

        jLabel5.setText("Contraceña");

        jLabel6.setText("Formato de salida");

        jMenu2.setText("Archivo");

        jMenu1.setText("Texto");

        jMenuItem6.setText("Abrir archivo TXT");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem6);

        jMenuItem7.setText("Abrir archivo X16KEY");
        jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem7ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem7);

        jMenuItem3.setText("Abrir imagen PNG");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenu2.add(jMenu1);

        jMenuItem4.setText("Imagenes");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem4);

        jMenuItem5.setText("Archivos binarios");
        jMenu2.add(jMenuItem5);

        jMenuBar1.add(jMenu2);

        jMenu4.setText("HASH");

        jMenu5.setText("Generar HASH de archivos");

        jMenuItem8.setText("MD5");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem8);

        jMenuItem9.setText("SHA1");
        jMenuItem9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem9ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem9);

        jMenu4.add(jMenu5);

        jMenuItem10.setText("HASH de texto");
        jMenuItem10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem10ActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem10);

        jMenuBar1.add(jMenu4);

        jMenu3.setText("Ayuda");

        jMenuItem11.setText("Configuracion");
        jMenu3.add(jMenuItem11);

        jMenuItem1.setText("Manual");
        jMenu3.add(jMenuItem1);

        jMenuItem2.setText("Acerca de");
        jMenu3.add(jMenuItem2);

        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Crip, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(jTextField5)
                        .addGap(18, 18, 18)
                        .addComponent(D_Crip)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(jRadioButton1)
                        .addGap(18, 18, 18)
                        .addComponent(jRadioButton2))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton7)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jProgressBar1, javax.swing.GroupLayout.DEFAULT_SIZE, 348, Short.MAX_VALUE))
                    .addComponent(jTextField1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jCheckBox1)
                        .addGap(18, 18, 18)
                        .addComponent(jRadioButton5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jRadioButton6)
                        .addGap(91, 91, 91)
                        .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jCheckBox2)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Random_Key)
                            .addComponent(jLabel5)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(HASH_GENERADO, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField3)
                            .addComponent(jTextField4))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jCheckBox1)
                        .addComponent(jRadioButton5)
                        .addComponent(jRadioButton6)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jCheckBox2, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(HASH_GENERADO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Random_Key)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(Crip)
                        .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel4))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jRadioButton2)
                        .addComponent(jRadioButton1)
                        .addComponent(jLabel6)
                        .addComponent(D_Crip)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton7)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jProgressBar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    public String MD5(){
        return "";
    }
    
    public void CLS(){
        jTextArea1.setText("");
        jTextField1.setText("");
        HASH_GENERADO.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
        jTextField5.setText("");
        jTextField7.setText("");
        jTextField8.setText("");
        jLabel2.setText("");
    }
    public void Abriri() throws IOException{
        OBJ.DATALEIDA="";
        HASHINT.clear();
        jLabel3.setText("ABRIENDO IMAGEN");
        jLabel3.setForeground(Color.YELLOW);
        jTextArea1.setText("");
        contenido="";
        abriri=false;
        abrirArchivo = new JFileChooser();
        abrirArchivo.setDialogTitle("Seleccionar Imagen");
        FileNameExtensionFilter filtroImagen = new FileNameExtensionFilter("PNG","png");
        abrirArchivo.setFileFilter(filtroImagen);
        String path="";
        int n=0,DATO;
        BufferedImage PNG=null;
        abrirArchivo.setFileSelectionMode( JFileChooser.FILES_ONLY );
        int seleccion = abrirArchivo.showOpenDialog( this );
        if( seleccion == JFileChooser.APPROVE_OPTION ){
            File f = abrirArchivo.getSelectedFile();
            try{
                path = f.getAbsolutePath();
                String name=f.getName();
                jTextField5.setText(name.substring(0, name.length()-4));
                PNG=ImageIO.read(f);
            }catch( Exception exp){}
        }
        jTextField1.setText(path);
        String HX,D="";
        try{
        n=PNG.getTileWidth();
        HX="";
        int Tam=0,z=0;
        DATO=PNG.getRGB(0, 0);
        HX=Integer.toHexString(DATO);
        Tam=Integer.parseInt(HX.substring(2, 8),16)/3;
        int T=Integer.parseInt(HX.substring(2, 8),16),TF;
        for(int x=0;x<n;x++){
            for(int y=0;y<n;y++){
                if(z==Tam+1)
                    break;
                if(x==0&&y==0)
                    y=1;
                DATO=PNG.getRGB(y, x);
                HX=Integer.toHexString(DATO);
                D=D+HX.substring(2, 8).toUpperCase();
                z++;
            }
            if(z==Tam+1)
                break;
        }
        if(D.length()-6==T*2){
            TF=6;
        }else if(D.length()-4==T*2){
            TF=4;
        }else{
            TF=2;
        }
        D=D.substring(0, D.length()-TF);
        if(jCheckBox1.isSelected())
            if(jRadioButton5.isSelected())
                OBJ.HASH(HASHINT.toString(),"MD5");
            else
                OBJ.HASH(HASHINT.toString(),"SHA1");
        OBJ.DATALEIDA=D;
        }catch(Exception e){
            System.err.println(e.getClass());
        }
        jLabel3.setText("LISTO");
        jLabel3.setForeground(Color.GREEN);
    }
    public void Crip() throws IOException{
        CRIP=false;
        OBJ.a=256;
        HASHINT.clear();
        File EXISTE=new File(jTextField5.getText()+((jRadioButton1.isSelected())?".png":".x16key"));
        int Band=0;
        if(EXISTE.exists()){
            Band=JOptionPane.showConfirmDialog(null, "El archivo con el nombre: "+jTextField5.getText()+((jRadioButton1.isSelected())?".png":".x16key")+", ya existe\n¿Desea remplazarlo?", "Archivo existente", 0 , 0);
            if(Band==0){
                EXISTE.delete();
            }
        }if(Band==0){
        jLabel3.setText("ENCRIPTANDO");
        jLabel3.setForeground(Color.YELLOW);
        if(jTextField5.getText().length()==0){
            NAME="KEY";
        }else
            NAME=jTextField5.getText();
        int CRY,VAL=0,DDR;
        String GG=jTextArea1.getText();
        for(int x=0;x<jTextArea1.getText().length();x++){
            CRY=GG.charAt(x);
            DDR=OBJ.Random();
            VAL=OBJ.DatoHex(CRY,DDR,VAL);
            if(jRadioButton2.isSelected()){
                OBJ.file(VAL);
            }
            HASHINT.add(VAL);
        }
        if(jRadioButton1.isSelected())
            OBJ.img(HASHINT);
        jTextField7.setText(String.valueOf(jTextArea1.getText().length()));
        jTextField8.setText(String.valueOf(HASHINT.size()));
        
        if(jTextArea1.getText().length()==HASHINT.size()){
            jLabel2.setForeground(Color.green);
            jLabel2.setText("TRUE");
        }
        else{
            jLabel2.setForeground(Color.red);
            jLabel2.setText("FALSE");
        }
        if(jCheckBox1.isSelected())
            if(jRadioButton5.isSelected())
                OBJ.HASH(HASHINT.toString(),"MD5");
            else
                OBJ.HASH(HASHINT.toString(),"SHA1");
        String ff=HASH_GENERADO.getText();
        HASH_GENERADO.setText(ff);
        jLabel3.setText("LISTO");
        jLabel3.setForeground(Color.GREEN);
        }
    }
    public void Read(){
        read=false;
        jLabel3.setText("LEYENDO");
        jLabel3.setForeground(Color.YELLOW);
        OBJ.ABRIRFILE();
        jLabel3.setText("LISTO");
        jLabel3.setForeground(Color.GREEN);
    }
    public void AbrirF() throws IOException{
        OBJ.DATALEIDA="";
        jLabel3.setText("ABRIRENDO ARCHIVO");
        jLabel3.setForeground(Color.YELLOW);
        abrirf=false;
        contenido="";
        HASHINT.clear();
        jTextArea1.setText("");
        OBJ.ABRIRFILEBIN();
        if(jCheckBox1.isSelected())
            if(jRadioButton5.isSelected())
                OBJ.HASH(HASHINT.toString(),"MD5");
            else
                OBJ.HASH(HASHINT.toString(),"SHA1");
        jLabel3.setText("LISTO");
        jLabel3.setForeground(Color.GREEN);
        jTextField5.setText(name);
        jProgressBar1.setValue(0);
    }
    public void Dcrip(){
        OBJ.a=256;
        DCRIP=false;
        jLabel3.setText("DESENCRIPTANDO");
        jLabel3.setForeground(Color.YELLOW);
        jTextArea1.setText("");
        jTextField7.setText(String.valueOf(jTextArea1.getText().length()));
        OBJ.DCRIPT(0);
        jTextArea1.setText(OBJ.TXTDC);
        jTextField8.setText(String.valueOf(jTextArea1.getText().length()));
        jLabel3.setText("LISTO");
        jLabel3.setForeground(Color.GREEN);
    }
    private void D_CripActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_D_CripActionPerformed
        DCRIP=true;
        h1 = new Thread(this);
        h1.start();
        
    }//GEN-LAST:event_D_CripActionPerformed

    private void Random_KeyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Random_KeyActionPerformed
        OBJ.RandomKey();
    }//GEN-LAST:event_Random_KeyActionPerformed

    private void CripActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CripActionPerformed
        h1 = new Thread(this);
        h1.start();
        CRIP=true;
    }//GEN-LAST:event_CripActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        jTextArea1.setText("");
        jTextField1.setText("");
        HASH_GENERADO.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
        jTextField5.setText("");
        jTextField7.setText("");
        jTextField8.setText("");
        jLabel2.setText("");
        HASHM="";
        HASHS="";
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        if(jCheckBox1.isSelected()){
            if(jRadioButton5.isSelected())
                HASH_GENERADO.setText(HASHM);
            else
                HASH_GENERADO.setText(HASHS);
            jRadioButton5.setVisible(true);
            jRadioButton6.setVisible(true);
        }else{
            HASH_GENERADO.setText("");
            jRadioButton5.setVisible(false);
            jRadioButton6.setVisible(false);
        }
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void jRadioButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton5ActionPerformed
        jLabel1.setText("HASH MD5");
        HASH_GENERADO.setText(HASHM);
    }//GEN-LAST:event_jRadioButton5ActionPerformed

    private void jRadioButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton6ActionPerformed
        jLabel1.setText("HASH SHA1");
        HASH_GENERADO.setText(HASHS);
    }//GEN-LAST:event_jRadioButton6ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        abriri=true;
        h1 = new Thread(this);
        h1.start();
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jMenuItem7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem7ActionPerformed
        abrirf=true;
        h1 = new Thread(this);
        h1.start();
    }//GEN-LAST:event_jMenuItem7ActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
        h1=new Thread(this);
        h1.start();
        read=true;
    }//GEN-LAST:event_jMenuItem6ActionPerformed
    
    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        if(!IMG.isVisible())
            IMG.setVisible(true);
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void jMenuItem8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem8ActionPerformed
        HASHFILE HF=new HASHFILE();
        HF.setVisible(true);
        HF.setTitle("HASH MD5");
        HF.HASH="MD5";
    }//GEN-LAST:event_jMenuItem8ActionPerformed

    private void jMenuItem9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem9ActionPerformed
        HASHFILE HF=new HASHFILE();
        HF.setVisible(true);
        HF.setTitle("HASH SHA1");
        HF.HASH="SHA1";
    }//GEN-LAST:event_jMenuItem9ActionPerformed

    private void jMenuItem10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem10ActionPerformed
        HASH_TXT HT=new HASH_TXT();
        HT.setVisible(true);
    }//GEN-LAST:event_jMenuItem10ActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CRIPEX16.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CRIPEX16.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CRIPEX16.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CRIPEX16.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CRIPEX16().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JButton Crip;
    public static javax.swing.JButton D_Crip;
    public static javax.swing.JTextField HASH_GENERADO;
    public static javax.swing.JButton Random_Key;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    public static javax.swing.JButton jButton7;
    public static javax.swing.JCheckBox jCheckBox1;
    public static javax.swing.JCheckBox jCheckBox2;
    public static javax.swing.JLabel jLabel1;
    public static javax.swing.JLabel jLabel2;
    public static javax.swing.JLabel jLabel3;
    public static javax.swing.JLabel jLabel4;
    public static javax.swing.JLabel jLabel5;
    public static javax.swing.JLabel jLabel6;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem10;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JMenuItem jMenuItem9;
    public static javax.swing.JProgressBar jProgressBar1;
    public static javax.swing.JRadioButton jRadioButton1;
    public static javax.swing.JRadioButton jRadioButton2;
    public static javax.swing.JRadioButton jRadioButton5;
    public static javax.swing.JRadioButton jRadioButton6;
    public static javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTextArea jTextArea1;
    public static javax.swing.JTextField jTextField1;
    public static javax.swing.JTextField jTextField3;
    public static javax.swing.JTextField jTextField4;
    public static javax.swing.JTextField jTextField5;
    public static javax.swing.JTextField jTextField7;
    public static javax.swing.JTextField jTextField8;
    // End of variables declaration//GEN-END:variables

    private String getArchivo(String path) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
